const express = require('express');
const blogController = require('../controllers/blogController'); // Import correctly
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

// Use the correct references
router.post('/', protect, blogController.createBlog);
router.get('/', blogController.getBlogs);

module.exports = router;

const createBlog = async (req, res) => {
    try {
        res.status(201).json({ message: 'Blog created successfully!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getBlogs = async (req, res) => {
    try {
        res.json([{ title: 'First Blog', content: 'Hello World' }]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// ✅ Ensure you export the functions correctly
module.exports = { createBlog, getBlogs };

