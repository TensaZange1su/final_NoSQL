import React from 'react';
const App = () => {
    return <h1>Welcome to Personal Blog</h1>;
};
export default App;
