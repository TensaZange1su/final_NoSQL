const mongoose = require('mongoose');

const BlogSchema = new mongoose.Schema({
    title: { type: String, required: true },
    content: { type: String, required: true },
    author: { type: String, required: true },
    sentiment: { 
        label: { type: String }, // Позитивный Негативный Нейтральный
        score: { type: Number }  // Уверенность в проценте (0-1)
    },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Blog', BlogSchema);
