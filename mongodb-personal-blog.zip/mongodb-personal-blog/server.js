const express = require('express');
const connectDB = require('./config/db');
const mongoose = require('mongoose');
const cors = require('cors');
const axios = require('axios'); 
const Blog = require('./models/Blog');
const User = require('./models/User');

const app = express();
connectDB();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// proxy from 5000 for ml
app.post('/ml/analyze', async (req, res) => {
    try {
        const mlResponse = await axios.post("http://127.0.0.1:8000/analyze", req.body);
        res.json(mlResponse.data);
    } catch (err) {
        res.status(500).json({ error: "ML API is unavailable", details: err.message });
    }
});

app.get('/ml-test', (req, res) => {
    res.send(`
        <h1>Test ML API (Swagger)</h1>
        <form id="mlForm">
            <textarea id="mlText" placeholder="Enter text for analysis" required></textarea><br>
            <button type="submit">Analyze</button>
        </form>
        <p id="result"></p>
        
        <script>
            document.getElementById("mlForm").addEventListener("submit", async function(event) {
                event.preventDefault();
                
                const text = document.getElementById("mlText").value;
                
                const response = await fetch("/ml/analyze", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ text })
                });

                const data = await response.json();
                document.getElementById("result").innerHTML = "Sentiment: " + data.label + " (Confidence: " + data.score.toFixed(2) + ")";
            });
        </script>
    `);
});


//analyze
app.post('/api/blogs', async (req, res) => {
    console.log("Received request:", req.body);

    try {
        const { title, content, author } = req.body;

        // through 5000
        const mlResponse = await axios.post("http://localhost:5000/ml/analyze", { text: content });
        console.log("ML Response:", mlResponse.data); // Логируем ответ от ML API

        const sentiment = mlResponse.data; // Получаем анализ тональности

        // saving
        const newBlog = new Blog({ title, content, author, sentiment });
        await newBlog.save();
        res.status(201).json(newBlog);
    } catch (err) {
        console.error("ML API error:", err.message);
        res.status(500).json({ error: "Ошибка при анализе тональности", details: err.message });
    }
});



//outputting all blogs
app.get('/api/blogs', async (req, res) => {
    try {
        const blogs = await Blog.find();
        res.json(blogs);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

//delete
app.delete('/api/blogs/:id', async (req, res) => {
    try {
        const blog = await Blog.findByIdAndDelete(req.params.id);
        if (!blog) return res.status(404).json({ error: 'Blog not found' });
        res.json({ message: 'Blog deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

//update
app.put('/api/blogs/:id', async (req, res) => {
    try {
        const { title, content, author } = req.body;
        const updatedBlog = await Blog.findByIdAndUpdate(req.params.id, { title, content, author }, { new: true });
        if (!updatedBlog) return res.status(404).json({ error: 'Blog not found' });
        res.json(updatedBlog);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

//front
app.get('/', (req, res) => {
    res.send(`
        <h1>Welcome to Personal Blog</h1>

        <h2>Create a Blog</h2>
        <form id="blogForm">
            <input type="text" id="title" placeholder="Title" required /><br>
            <textarea id="content" placeholder="Content" required></textarea><br>
            <input type="text" id="author" placeholder="Author" required /><br>
            <button type="submit">Create Blog</button>
        </form>
        <a href="/blogs">View Blogs</a>
        
        <h2>Analyze Sentiment of Blogs</h2>
        <form id="mlForm">
            <textarea id="mlText" placeholder="Enter text for analysis" required></textarea><br>
            <button type="submit">Analyze</button>
        </form>
        <p id="mlResult"></p>

        <script>
            // Создание блога
            document.getElementById("blogForm").addEventListener("submit", async function(event) {
                event.preventDefault();
                
                const title = document.getElementById("title").value;
                const content = document.getElementById("content").value;
                const author = document.getElementById("author").value;

                await fetch("/api/blogs", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ title, content, author })
                });
                window.location.href = "/blogs";
            });

            // Анализ тональности
            document.getElementById("mlForm").addEventListener("submit", async function(event) {
                event.preventDefault();
                
                const text = document.getElementById("mlText").value;
                
                const response = await fetch("/ml/analyze", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ text })
                });

                const data = await response.json();
                document.getElementById("mlResult").innerHTML = 
                    "<strong>Sentiment:</strong> " + data.label + 
                    " <br><strong>Confidence:</strong> " + (data.score * 100).toFixed(2) + "%";
            });
        </script>
    `);
});


app.get('/blogs', async (req, res) => {
    try {
        const blogs = await Blog.find();

        res.send(`
            <h1>All Blogs</h1>
            <ul>
                ${blogs.map(blog => {
                    const sentiment = blog.sentiment?.label || 'Unknown';
                    const score = blog.sentiment?.score ? (blog.sentiment.score * 100).toFixed(2) : 'N/A';

                    let color;
                    if (sentiment === "POSITIVE") color = "green";
                    else if (sentiment === "NEGATIVE") color = "red";
                    else color = "orange";

                    return `
                        <li>
                            <h3>${blog.title}</h3>
                            <p>${blog.content}</p>
                            <p><strong>Author:</strong> ${blog.author}</p>
                            <p><strong>Sentiment:</strong> 
                                <span style="color: ${color}; font-weight: bold;">
                                    ${sentiment} (${score}%)
                                </span>
                            </p>
                            <button onclick="deleteBlog('${blog._id}')">Delete</button>
                            <button onclick="editBlog('${blog._id}', '${blog.title}', '${blog.content}', '${blog.author}')">Edit</button>
                        </li>
                    `;
                }).join('')}
            </ul>
            <a href="/">Back to Home</a>
            <script>
                async function deleteBlog(id) {
                    await fetch("/api/blogs/" + id, { method: "DELETE" });
                    location.reload();
                }
                
                async function editBlog(id, title, content, author) {
                    const newTitle = prompt("Edit Title:", title);
                    const newContent = prompt("Edit Content:", content);
                    if (newTitle && newContent) {
                        await fetch("/api/blogs/" + id, {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ title: newTitle, content: newContent, author })
                        });
                        location.reload();
                    }
                }
            </script>
        `);
    } catch (err) {
        res.status(500).send("<h1>Error loading blogs</h1><p>" + err.message + "</p>");
    }
});



const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
