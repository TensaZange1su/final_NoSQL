from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline

app = FastAPI()

classifier = pipeline("text-classification") #nlp modelзшз 

class BlogRequest(BaseModel):
    text: str

@app.post("/analyze")
def analyze_text(request: BlogRequest):
    result = classifier(request.text)
    return {"label": result[0]["label"], "score": result[0]["score"]}
