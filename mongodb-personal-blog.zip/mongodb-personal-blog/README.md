# Personal Blog using MongoDB
- MongoDB, Express.js, Node.js
- User Authentication (JWT)
- Blog CRUD operations
- Role-based Access Control
```